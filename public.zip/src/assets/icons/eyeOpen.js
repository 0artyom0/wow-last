import React from 'react';

function EyeOpen(props) {
    return (
        <svg viewBox="-20 -200 320 400" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
            <g id="eye" stroke-width="30" fill="none">
                <g id="eye-lashes" stroke="currentColor">
                    <line x1="140" x2="140" y1="90" y2="180"></line>
                    <line x1="70" x2="10" y1="60" y2="140"></line>
                    <line x1="210" x2="270" y1="60" y2="140"></line>
                </g>
                <path id="eye-bottom" d="m0,0q140,190 280,0" stroke="currentColor"></path>
                <path id="eye-top" d="m0,0q140,190 280,0" stroke="currentColor"></path>
                <circle id="eye-pupil" cx="140" cy="0" r="50" fill="currentColor" stroke="none"></circle>
            </g>
        </svg>
    );
}

export default EyeOpen;
