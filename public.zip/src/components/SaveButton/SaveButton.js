import HEART from "../../assets/icons/heart-gray.svg";
import HEART_FILL from "../../assets/icons/heart-pink.svg";
import "./style.css";

const SaveButton = ({ onClick, isSaved,isNew=false , isSingle=false }) => {
  return (
    <button
        style={{
            position:isNew ? 'absolute' :'',
            right: isNew ? 20  : isSingle ? -25 : 0,
            top:isNew ? 20  : isSingle ? -50 : 0,
        }}
      className={`${isSaved && "productSaveBtnTrue"} productSaveBtn`}
      onClick={onClick}>
      <img src={HEART} alt='Heart' className='notSavedImg' />
      <img src={HEART_FILL} alt='Heart Filled' className='savedImg' />
    </button>
  );
};

export default SaveButton;
