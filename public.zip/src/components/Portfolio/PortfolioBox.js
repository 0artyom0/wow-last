import SecondButton from "../SecondButton/SecondButton";
import "./style.css";
import {useSelector} from "react-redux";

const PortfolioBox = ({ className, img, name, description, to }) => {
    const theme = useSelector(state => state.newReducer.themeChange)

    return (
    <div
      className={`${className} portfolioBox`}
      style={{ backgroundImage: `url(${img})` , overflow:theme==='ligth' ? "hidden" : '' }}>
      <div className='portfolioBoxInfo'>
        <div className='portfolioBoxTitleWrapper'>
          <p className='portfolioBoxTitle'>{name}</p>
          <p className='portfolioBoxDesc'>{description}</p>
        </div>
        <SecondButton className='moreBtnLarge portfolioWorkMoreBtn' to={to} />
      </div>
    </div>
  );
};

export default PortfolioBox;
