import Slider from "../Slider/Slider";
import Title from "../Title/Title";
// import PARTNER_1 from "../../assets/partners/partner-1.svg";
import "./style.css";
import Img from "../Img";
import { STORAGE_URL } from "../../services/apiService";
import { useEffect, useState } from "react";
import { useWindowSize } from "../../hooks/useWindowSize";
import Cookies from "js-cookie";
import { useTranslation } from "react-i18next";
import {useSelector} from "react-redux";

const Partners = ({ partners }) => {
  const { t } = useTranslation();
  const theme = useSelector(state => state.newReducer.themeChange)
  const lang = Cookies.get("i18next") || "en";
  const [showArrowBtns, setShowArrowBtns] = useState(false);
  const { width } = useWindowSize();
  const trans = useSelector(state => state.newReducer.trans)
  useEffect(() => {
    const sliderContainer = document.querySelector(".slider ");
    const items = document.querySelectorAll(".partnerWrapper");
    const gap = 32;
    let totalWidth = 0;
    if (sliderContainer && items) {
      items.forEach(img => {
        //@ts-ignore
        totalWidth += img.offsetWidth + gap;
      });
      //@ts-ignore
      setShowArrowBtns(totalWidth > sliderContainer.offsetWidth);
    }
  }, [width]);

  return (
    <div style={{
      background:theme === 'ligth' ? "#F8F8F8" : ''
    }} className='partnersContainer container'>
      {trans.filter((e)=>e.key ==='OUR_PARTNERS').map((e)=>(
          <Title title={e[`value_${lang}`]} />
      ))}
      <Slider className='partnersSlider' showArrowBtns={showArrowBtns}>
        {partners.partners.map(partner => (
          <div className='partnerWrapper' key={partner.id}>
            <div className='partner'>
              <Img
                src={`${STORAGE_URL}/${partner.logo}`}
                alt={partner.logo_title_en}
              />
              <p style={{
                color:theme === 'ligth' ? "#000" : ''
              }}>{partner[`logo_title_${lang}`]}</p>
            </div>
          </div>
        ))}
      </Slider>
    </div>
  );
};

export default Partners;
