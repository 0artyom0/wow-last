function adminScript() {
    let minDate, maxDate;
    const currentDate = new Date();
    let yearMonth = currentDate.getFullYear();
    let monthMonth = currentDate.getMonth() + 1;
    const dayMonth = '01';
    if (monthMonth < 10) {
        monthMonth = '0' + monthMonth;
    }
    const formattedDateMonth = `${yearMonth}-${monthMonth}-${dayMonth}`;
    let yearDay = currentDate.getFullYear();
    let monthDay = currentDate.getMonth() + 1;
    let dayDay = currentDate.getDate();
    if (monthDay < 10) {
        monthDay = '0' + monthDay;
    }
    if (dayDay < 10) {
        dayDay = '0' + dayDay;
    }
    const formattedDateDay = `${yearDay}-${monthDay}-${dayDay}`;

    $(document).ready(function () {
        const inputMin = document.getElementById('min')
        const inputMax = document.getElementById('max')
        inputMin.value = formattedDateMonth
        inputMax.value = formattedDateDay
    })
    $(document).ready(function () {
        minDate = new DateTime('#min', {
            format: 'YYYY-MM-DD',
            value: '2024-01-01'
        });
        maxDate = new DateTime('#max', {
            format: 'YYYY-MM-DD'
        });
        $('#min, #max').on('change', function () {
            minDate = $('#min').val();
            maxDate = $('#max').val();
            getAllInfo(minDate, maxDate)
        });
    })

    function groupDataForLeadId(data) {
        const groupedData = {};
        data.forEach((element) => {
            if (!groupedData[element.naem]) {
                groupedData[element.name] = {...element, id: element.id, quantity: 0, price: 0};
            }
            groupedData[element.name].quantity += +element.quantity;
            groupedData[element.name].price += +element.price;
        });
        return Object.values(groupedData).map(item => {
            return {
                ...item,
                totalPrice: +item.quantity * +item.price
            };
        });
    }

    function getAllInfo(minDateApi, maxDateApi) {
        const spinner = document.querySelector('.center')
        const container = document.querySelector('.admin-container')
        try {
            container.style.display = 'none'
            spinner.style.display = 'block'
            let user_id = null;
            BX24.callMethod('user.current', {}, function (res) {
                user_id = res.data().ID;
                const token = 'r5nht443dae4ce8fd80406baac042ebgj';
                fetch(`https://machtech.site/WowEffect/report/actions.php?token=${token}&user_id=${1}&start=${minDateApi || formattedDateMonth}&end=${maxDateApi || formattedDateDay}`)
                    .then(response => response.json())
                    .then(async data => {
                        const newData = groupDataForLeadId(data)
                        const reportTable = document.getElementById('adminTableBody')
                        reportTable.innerHTML = '';
                        if ($.fn.DataTable.isDataTable('#admin-table')) {
                            $('#admin-table').DataTable().clear().destroy();
                        }
                        $('#admin-table').DataTable().clear();
                        $('#admin-table').DataTable().destroy();
                        for (const item of newData) {
                            const leadId = item.lead_id;
                            const projectName = item.name || '';
                            const quantity = +item.quantity;
                            const pricePerUnit = +item.price;
                            const totalSalary = quantity * pricePerUnit;
                            // const createdAt = item.date_create.split(' ')[0]
                            // const leadName = await getLeadNameById(leadId) || '';
                            const row = reportTable.insertRow();
                            const leadNameCell = row.insertCell(0);
                            const projectNameCell = row.insertCell(1);
                            const quantityCell = row.insertCell(2);
                            const pricePerUnitCell = row.insertCell(3);
                            const totalSalaryCell = row.insertCell(4);
                            // const createdCell = row.insertCell(5);
                            leadNameCell.innerHTML = projectName;
                            leadNameCell.style.cursor = 'pointer'
                            // projectNameCell.innerHTML = projectName;
                            const inputFixedPrice = document.createElement("input")
                            inputFixedPrice.className = 'custom-input'
                            inputFixedPrice.placeholder ='Enter Fixed Salary ...'
                            projectNameCell.appendChild(inputFixedPrice)
                            quantityCell.innerHTML = quantity;
                            const inputReceived = document.createElement('input')
                            // pricePerUnitCell.innerHTML = pricePerUnit;
                            inputReceived.className = 'custom-input'
                            inputReceived.placeholder = 'Enter Amount received ...'
                            pricePerUnitCell.appendChild(inputReceived)
                            totalSalaryCell.innerHTML = totalSalary;
                            // createdCell.innerHTML = createdAt
                            leadNameCell.addEventListener("click", () => {
                                BX24.openPath(`/crm/lead/details/${leadId}/`);
                            })
                        }
                        $(document).ready(function () {
                            $('#admin-table').DataTable();
                        })
                        spinner.style.display = 'none'
                        container.style.display = 'block'
                    })
                    .catch(error => console.error('error', error));
            });
        } catch (error) {
            console.error('error', error);
        }
    }

    async function getLeadNameById(leadId) {
        try {
            return await new Promise((resolve, reject) => {
                BX24.callMethod(
                    "crm.lead.get",
                    {"id": leadId},
                    function (result) {
                        if (result.error()) {
                            reject(result.error());
                        } else {
                            resolve(result.data().TITLE);
                        }
                    }
                );
            });
        } catch (error) {
            console.error("Error occurred while fetching lead:", error);
            return "";
        }
    }

    BX24.init(function () {
        BX24.callMethod("profile", {}, function (res) {
            const user = res.data()
            console.log(user)
            if (false) {
                const adminContent = document.querySelector('.admin-container')
                adminContent.remove()
                const divElement = document.createElement("div");
                divElement.className = "no-admin";
                const headingElement = document.createElement("h1");
                const headingText = document.createTextNode("You Are Not Admin");
                headingElement.appendChild(headingText);
                divElement.appendChild(headingElement);
                const bodyElement = document.body;
                bodyElement.appendChild(divElement);
            } else {
                document.querySelector('.admin-container').style.display = 'block'
            }
        })
        getAllInfo()
    })
}
adminScript()
