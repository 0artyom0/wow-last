import axios from "axios";

// const BASE_URL = process.env.WOW_EFFECT_BASE_URL;
const BASE_URL = "https://prod.machtech.site/WowEffect/adminPanel/api";
export const STORAGE_URL = "https://prod.machtech.site/WowEffect/adminPanel";

const apiService = {
  get: async (endpoint, params = {}, headers = {}) => {
    try {
      const response = await axios.get(`${BASE_URL}/${endpoint}?page=${params.page}`);
      return response.data;
    } catch (error) {
      throw error;
    }
  },
  post: async (endpoint, data = {}, headers = {}, setStateCallback) => {
    try {
      setStateCallback({ loading: true, error: null, data: null });
      const response = await axios.post(`${BASE_URL}/${endpoint}`, data, {
        headers: {
          "Content-Type": "multipart/form-data",
          ...headers,
        },
      });
      setStateCallback({ loading: false, error: null, data: response.data });
    } catch (error) {
      setStateCallback({ loading: false, error, data: null });
    }
  },
};

export default apiService;
