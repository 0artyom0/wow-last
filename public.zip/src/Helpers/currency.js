export default '֏'
