export const initial = {
  opacity: 0,
};

export const animate = {
  opacity: 1,
};
